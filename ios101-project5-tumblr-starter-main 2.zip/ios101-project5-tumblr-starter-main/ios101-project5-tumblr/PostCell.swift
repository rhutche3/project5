//
//  PostCell.swift
//  ios101-project5-tumblr
//
//  Created by Ryan Hutchens on 3/30/25.
//

import UIKit

class PostCell: UITableViewCell{
    
    @IBOutlet weak var postImageView: UIImageView!
    @IBOutlet weak var summaryLabel: UILabel!
    
    override func awakeFromNib(){
        super.awakeFromNib()
        postImageView.layer.cornerRadius = 8
        postImageView.clipsToBounds = true
    }
}
